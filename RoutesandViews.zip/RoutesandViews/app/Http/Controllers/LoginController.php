<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Services\Business\SecurityService;
use Symfony\Contracts\Service\Attribute\Required;


class LoginController extends Controller
{
    // To obtain an instance of the current http request from the post
    
    public function index (Request $request)
    {
        $this->validateForm($request);
        // This is from the next step d. in the activity
        // create a user model with username and password
        $user = new UserModel($request->input('username'), $request->input('password'));
        
        // Instantiate the business layer
        $serviceLogin = new SecurityService();
        
        // Pass the credentials to the business layer
        // Should return a number of results
        $isValid = $serviceLogin->login($user);
        if($serviceLogin->login($user) > 0){
            return view('loginPassed');
        }
        else{
            return view('loginfailed');
        }      
             
    }
    
    public function validateForm(Request $request){
        
        $rules = ['username' => 'Required|Between: 4,10|Alpha', 'password' => 'Required|Between: 4,10' ];
        // Run Data Validation Rules
        $this->validate($request, $rules);     
        
    }
    
    
}
