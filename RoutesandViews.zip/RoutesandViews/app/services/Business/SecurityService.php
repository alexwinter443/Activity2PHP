<?php

namespace App\Services\Business;

use App\Models\UserModel;
use App\Services\Data\SecurityDAO;

class SecurityService{
    
    private $verifyCred;
    
    
    public function login(UserModel $credentials){
        // Instantiate the data Access layer
        $this->verifyCred = new SecurityDAO();
    
        
        // return true or false by passing credentials to the object
        return $this->verifyCred->findByUser($credentials);   
        
    
    
    }
    
}
