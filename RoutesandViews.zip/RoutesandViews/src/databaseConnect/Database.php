<?php 


/*
 * CST-256 Database Application Programming 3
 * Vien Nguyen
 * Database class
 *  Jan/22nd/20
 * This class is responsible for communicating to the database server and connect to the database
 * */
class Database{
    //Server properties
    private $dbservername = "localhost:8889";
    private $dbusername = "root";
    private $dbpassword = "root";
    private $dbname = "cst256";
    
    //Get connection method will open a connection to the server.
    function getConnection(){
        $conn = new mysqli($this->dbservername, $this->dbusername,$this->dbpassword, $this->dbname);
        
        //Return the connection result
        if($conn->connect_error){
            echo("Connection failed " .$conn->connect_error . "<br>");   
        }else{
            return $conn;
        }
    }
}